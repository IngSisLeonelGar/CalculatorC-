﻿using ConsoleCalculadora;
using System.Runtime.InteropServices;
using System;

internal class Program

{
    private static void Main(string[] args)
    {
        int Continuar = 0;
        do
        {
            Console.WriteLine("---------CALCULADORA---------");
            Console.WriteLine("****    1. SUMAR         ****");
            Console.WriteLine("****    2. RESTA         ****");
            Console.WriteLine("****    3. MULTIPLICAR   ****");
            Console.WriteLine("****    4. DIVIDIR       ****");
            Console.WriteLine("****    5. SALIR         ****");
            Console.WriteLine("-----------------------------");
            Calculadora Objcalculadora = new Calculadora();
            String Respuesta, Numero1, Numero2;
            int valor, RespuestaN, RespuestaOperacion, Numero1int, Numero2int;
            double valor2, RespuestaNdouble, RespuestaOperaciondouble, Numero1double, Numero2double;
            bool isNumber, isNumber2;
            Respuesta = Console.ReadLine();
            RespuestaN = int.Parse(Respuesta);
            if (RespuestaN == 5)
            {
                Continuar = 1;
            }
            else
            {
                switch (RespuestaN)
                {
                    case 1:
                        Console.WriteLine("Escriba el Primer Numero (usar coma para numeros decimales)");
                        Numero1 = Console.ReadLine();
                        Console.WriteLine("Escriba el segundo Numero (usar coma para numeros decimales)");
                        Numero2 = Console.ReadLine();
                        isNumber = int.TryParse(Numero1, out valor);
                        isNumber2 = double.TryParse(Numero1, out valor2);
                        if(isNumber || isNumber2)
                        {
                            if(isNumber2)
                            {
                                Numero1double = Convert.ToDouble(Numero1);
                                Numero2double = Convert.ToDouble(Numero2);
                                RespuestaNdouble = Objcalculadora.Suma(Numero1double, Numero2double);
                                Console.WriteLine("El resultado es: " + RespuestaNdouble);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                            else
                            {
                                Numero1int = Convert.ToInt32(Numero1);
                                Numero2int = Convert.ToInt32(Numero2);
                                RespuestaOperacion = Objcalculadora.Suma(Numero1int, Numero2int);
                                Console.WriteLine("El resultado es: " + RespuestaOperacion);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Por favor ingresar numeros");
                            Console.ReadLine();
                            break;
                        }
                        
                    case 2:
                        Console.WriteLine("Escriba el Primer Numero");
                        Numero1 = Console.ReadLine();
                        Console.WriteLine("Escriba el segundo Numero");
                        Numero2 = Console.ReadLine();
                        isNumber = int.TryParse(Numero1, out valor);
                        isNumber2 = double.TryParse(Numero1, out valor2);
                        if (isNumber || isNumber2)
                        {
                            if (isNumber2)
                            {
                                Numero1double = Convert.ToDouble(Numero1);
                                Numero2double = Convert.ToDouble(Numero2);
                                RespuestaNdouble = Objcalculadora.Resta(Numero1double, Numero2double);
                                Console.WriteLine("El resultado es: " + RespuestaNdouble);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                            else
                            {
                                Numero1int = Convert.ToInt32(Numero1);
                                Numero2int = Convert.ToInt32(Numero2);
                                RespuestaOperacion = Objcalculadora.Resta(Numero1int, Numero2int);
                                Console.WriteLine("El resultado es: " + RespuestaOperacion);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Por favor ingresar numeros");
                            Console.ReadLine();
                            break;
                        }
                    case 3:
                        Console.WriteLine("Escriba el Primer Numero");
                        Numero1 = Console.ReadLine();
                        Console.WriteLine("Escriba el segundo Numero");
                        Numero2 = Console.ReadLine();
                        isNumber = int.TryParse(Numero1, out valor);
                        isNumber2 = double.TryParse(Numero1, out valor2);
                        if (isNumber || isNumber2)
                        {
                            if (isNumber2)
                            {
                                Numero1double = Convert.ToDouble(Numero1);
                                Numero2double = Convert.ToDouble(Numero2);
                                RespuestaNdouble = Objcalculadora.Multiplicacion(Numero1double, Numero2double);
                                Console.WriteLine("El resultado es: " + RespuestaNdouble);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                            else
                            {
                                Numero1int = Convert.ToInt32(Numero1);
                                Numero2int = Convert.ToInt32(Numero2);
                                RespuestaOperacion = Objcalculadora.Multiplicacion(Numero1int, Numero2int);
                                Console.WriteLine("El resultado es: " + RespuestaOperacion);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Por favor ingresar numeros");
                            Console.ReadLine();
                            break;
                        }
                    case 4:
                        Console.WriteLine("Escriba el Primer Numero");
                        Numero1 = Console.ReadLine();
                        Console.WriteLine("Escriba el segundo Numero");
                        Numero2 = Console.ReadLine();
                        isNumber = int.TryParse(Numero1, out valor);
                        isNumber2 = double.TryParse(Numero1, out valor2);
                        if (isNumber || isNumber2)
                        {
                            if (isNumber2)
                            {
                                Numero1double = Convert.ToDouble(Numero1);
                                Numero2double = Convert.ToDouble(Numero2);
                                RespuestaNdouble = Objcalculadora.Division(Numero1double, Numero2double);
                                Console.WriteLine("El resultado es: " + RespuestaNdouble);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                            else
                            {
                                Numero1int = Convert.ToInt32(Numero1);
                                Numero2int = Convert.ToInt32(Numero2);
                                RespuestaOperacion = Objcalculadora.Division(Numero1int, Numero2int);
                                Console.WriteLine("El resultado es: " + RespuestaOperacion);
                                Continuar = 0;
                                Console.ReadLine();
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Por favor ingresar numeros");
                            Console.ReadLine();
                            break;
                        }
                    default:
                        Console.WriteLine("Respuesta no aceptada");
                        Console.ReadLine();
                        break;
                }
            }
            Console.Clear();

        } while (Continuar != 1);
    }

}