﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleCalculadora
{
    public class Calculadora
    {
        int Numero1;
        int Numero2;
        double Numero11;
        double Numero12;

        public Calculadora()
        {
            Numero1 = 1;
            Numero2 = 1;
        }
        public Calculadora(int numero1, int numero2)
        {
            Numero1 = numero1;
            Numero2 = numero2;
        }
        public Calculadora(double numero1, double numero2)
        {
            Numero11 = numero1;
            Numero12 = numero2;
        }

        public int Suma(int N1, int N2)
        {
            int Numero1 = N1, Numero2 = N2;
            int Suma;
            Suma = Numero1 + Numero2;

            return Suma;
        }
        public int Resta(int N1, int N2)
        {
            int Numero1 = N1, Numero2 = N2;
            int Resta;
            Resta = Numero1 - Numero2;

            return Resta;
        }
        public int Multiplicacion(int N1, int N2)
        {
            int Numero1 = N1, Numero2 = N2;
            int Multiplicacion;
            Multiplicacion = Numero1 * Numero2;

            return Multiplicacion;
        }
        public int Division(int N1, int N2)
        {
            int Numero1 = N1, Numero2 = N2;
            int Division;
            Division = Numero1 / Numero2;

            return Division;
        }
        public double Suma(double N1, double N2)
        {
            double Numero1 = N1, Numero2 = N2;
            double Suma;
            Suma = Numero1 + Numero2;

            return Suma;
        }
        public double Resta(double N1, double N2)
        {
            double Numero1 = N1, Numero2 = N2;
            double Resta;
            Resta = Numero1 - Numero2;

            return Resta;
        }
        public double Multiplicacion(double N1, double N2)
        {
            double Numero1 = N1, Numero2 = N2;
            double Multiplicacion;
            Multiplicacion = Numero1 * Numero2;

            return Multiplicacion;
        }
        public double Division(double N1, double N2)
        {
            double Numero1 = N1, Numero2 = N2;
            double Division;
            Division = Numero1 / Numero2;

            return Division;
        }
    }
}
